DELETE FROM RESERVATION;
DELETE FROM EVENEMENT;
ALTER TABLE EVENEMENT ADD nomEv VARCHAR2(50);
/*==============================================================*/
/* INSERTION : EVENEMENT                                        */
/*==============================================================*/
INSERT INTO EVENEMENT (cdSite, numEv, dateDebEv, dateFinEv, nbPlaces, tarif, nomEv) SELECT cdSite, numEv, dateDebEv, dateFinEv, nbPlaces, tarif, nomEv FROM TESTSAELD.EVENEMENT WHERE (nbPlaces>20 OR nbPlaces IS NULL);

/*==============================================================*/
/* INSERTION : RESERVATION                                      */
/*==============================================================*/
INSERT INTO RESERVATION (SELECT cdPers, cdSite, numEv, dateInscr, nbPlResa, modeReglt FROM TESTSAELD.INSCRIPTION WHERE cdSite||numEv IN (SELECT cdSite||numEv FROM TESTSAELD.EVENEMENT WHERE (nbPlaces>20 OR nbPlaces IS NULL)));